function G = G_B_OmniD(theta)
theta_B = pi / 2 + deg2rad(10);
SLA = 30;
theta_3dB_B = deg2rad(65);
G_E_max = 8;
G_E_dB = G_E_max - min(12 * ((theta - pi / 2) / theta_3dB_B) .^ 2, SLA);
G_E = db2pow(G_E_dB);
N_B = 8;
AF = sin(N_B * pi / 2 * (cos(theta) - cos(theta_B))) ./ (N_B * sin(pi / 2 * (cos(theta) - cos(theta_B))));
AF(isnan(AF)) = 1;
G = G_E .* AF .^ 2;
end