%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of 3D Two-Hop Cellular Networks Analysis      %%%
%%%          with Wireless Backhauled UAVs                              %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical and simulation      %%%
%%%   data for Fig. 3, The joint distribution of r_D0 and theta_D0.     %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Parameters
datetime('now')
lambda_D = 1e-6;
h_D_min = 50;%-1e4;%
h_D_max = 200;%1e4;%
r_diff = 5;
r_max = 205;
r = h_D_min : r_diff : r_max;
theta = 0 : 0.05 : 1.3;
len_r = length(r);
len_theta = length(theta);
theta_D_min = acos(h_D_min ./ r);
theta_D_max = acos(min(h_D_max ./ r, 1));

%% Simulation
x_D_min = -1e4;
x_D_max = 1e4;
y_D_min = -1e4;
y_D_max = 1e4;
Num_D_Initial = lambda_D * (x_D_max - x_D_min) * (y_D_max - y_D_min) * (h_D_max - h_D_min);
Realizations = 1e5;
Closest_D = zeros(Realizations, 2);
tic
parfor i = 1 : Realizations
    Num_D = poissrnd(Num_D_Initial);
    Pos_D_x = unifrnd(x_D_min, x_D_max, [Num_D, 1]);
    Pos_D_y = unifrnd(y_D_min, y_D_max, [Num_D, 1]);
    Pos_D_z = unifrnd(h_D_min, h_D_max, [Num_D, 1]);
    Pos_D = [Pos_D_x, Pos_D_y, Pos_D_z];
    Pos_D_range = sqrt(sum(Pos_D .^ 2, 2));
    [r_tilde_D, ind_min_D] = min(Pos_D_range);
    theta_tilde_D = acos(Pos_D_z(ind_min_D) / r_tilde_D);
    Closest_D(i, :) = [r_tilde_D, theta_tilde_D];
end
toc
figure(401)
histogram2(Closest_D(:, 1), Closest_D(:, 2), 'Normalization', 'pdf')
hold on

%% Theory
beta = r .^ 3 .* (cos(theta_D_max) - cos(theta_D_min)) - 1 / 3 * r .^ 3 .* (cos(theta_D_max) .^ 3 - cos(theta_D_min) .^ 3);
PDF_Closest_3D_Thr = zeros(len_r, len_theta);
for ind_r = 2 : len_r
    for ind_theta = 1 : len_theta
        if (theta(ind_theta) <= theta_D_min(ind_r)) && (theta(ind_theta) >= theta_D_max(ind_r))
            PDF_Closest_3D_Thr(ind_r, ind_theta) = 2 * pi * lambda_D * r(ind_r) ^ 2 * exp(-pi * lambda_D * beta(ind_r)) * sin(theta(ind_theta));
        end
    end
end
surf(repmat(r, length(theta), 1), repmat(theta.', 1, length(r)), PDF_Closest_3D_Thr.')
xlabel('Distance $r$ (m)', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('Zenith Angle $\theta$ (rad)', 'Interpreter', 'latex', 'FontSize', 12)
zlabel('Joint pdf', 'Interpreter', 'latex', 'FontSize', 12)
box on
hold off
datetime('now')