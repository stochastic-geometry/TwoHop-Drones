%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of 3D Two-Hop Cellular Networks Analysis      %%%
%%%          with Wireless Backhauled UAVs                              %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the theoretical data for Fig. 4,    %%%
%%%   coverage probability as a function of mean UAV height.            %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Parameters
datetime('now')
lambda_B = 1e-6;
h_B = 20;
lambda_D = 1e-8;
h_D_mean_vec = [100 : 50 : 350, 400 : 100 : 900];
Num_Height = length(h_D_mean_vec);
Diff_Height = 100;
h_D_min_vec = h_D_mean_vec - Diff_Height / 2;
h_D_max_vec = h_D_mean_vec + Diff_Height / 2;
alpha = 3;
N0 = 1e-8;
P_B = db2pow(10);
P_D = db2pow(5);
G_max = db2pow(8);
tauVec_dB = (-12 : 4 : 0).';
tauVec = db2pow(tauVec_dB);
tauLen = length(tauVec);
ProbCover_Thr = zeros(tauLen, Num_Height);

%% MC Integration
phiB0D0_max = 2 * pi;
rD0_max = 3e3;%1e4;
thetaD0_max = pi / 2;
rB0_max = 3e3;%1e4;
z_max = 5;
MaxIter = 1e6;
for i_tau = 1 : tauLen
    disp(['i_tau: ', num2str(i_tau)])
    tau = tauVec(i_tau);
    for i_Height = 1 : Num_Height
        disp(['i_Height: ', num2str(i_Height)])
        h_D_min = h_D_min_vec(i_Height);
        h_D_max = h_D_max_vec(i_Height);
        fun = 0;
        tic
        parfor k = 1 : MaxIter
            phiB0D0 = rand * phiB0D0_max;
            rD0 = rand * rD0_max + h_D_min;
            thetaD0 = rand * thetaD0_max;
            rB0 = rand * rB0_max + h_B;
            z = rand * z_max;
            theta_D_M = acos(min(1, h_D_max ./ rD0));
            theta_D_m = acos(h_D_min ./ rD0);
            
            theta_D_M_fun = @(r) acos(min(1, h_D_max ./ r));
            theta_D_m_fun = @(r) acos(h_D_min ./ r);
            beta_fun = @(r) r .^ 3 .* ((cos(theta_D_M_fun(r)) - cos(theta_D_m_fun(r))) - 1 / 3 * (cos(theta_D_M_fun(r)) .^ 3 - cos(theta_D_m_fun(r)) .^ 3));
            f_z = @(z) exp(-z);
            f_rB0 = @(r) 2 * pi * lambda_B * r .* exp(-pi * lambda_B * (r .^ 2 - h_B ^ 2));
            f_rD0_thetaD0 = @(r, theta) 2 * pi * lambda_D * r .^ 2 .* exp(-pi * lambda_D * beta_fun(r)) .* sin(theta); % theta should be between theta_D_M and theta_D_m
            f_phiB0D0 = 1 / (2 * pi);
            a = @(rB0) P_B * G_B_OmniD(pi - acos(h_B ./ rB0)) .* rB0 .^ (-alpha);
            b = @(rD0, thetaD0) P_D * G_D_AC(pi - thetaD0) .* rD0 .^ (-alpha);
            r_B0D0 = @(rB0, rD0, thetaD0, phiB0D0) sqrt(rB0 .^ 2 + rD0 .^ 2 - 2 * h_B * rD0 .* cos(thetaD0) - 2 * sqrt(rB0 .^ 2 - h_B ^ 2) .* rD0 .* sin(thetaD0) .* cos(phiB0D0));
            c = @(rB0, rD0, thetaD0, phiB0D0) P_B * G_B_OmniD(acos((rD0 .* cos(thetaD0) - h_B) ./ r_B0D0(rB0, rD0, thetaD0, phiB0D0))) .* G_max .* r_B0D0(rB0, rD0, thetaD0, phiB0D0) .^ (-alpha);
            V0 = @(rB0, rD0, thetaD0, phiB0D0) 1 - exp(-N0 ./ c(rB0, rD0, thetaD0, phiB0D0) * tau);
            V1 = @(rB0, rD0, thetaD0) a(rB0) ./ (a(rB0) + b(rD0, thetaD0) * tau) .* exp(-tau ./ a(rB0) * N0 - 2 * pi * lambda_B * I1_V1(rB0, tau, P_B, h_B, alpha) - 2 * pi * lambda_D * (I2_V1(rB0, rD0, tau, P_B, h_B, P_D, h_D_min, h_D_max, alpha) + I3_V1(rB0, rD0, tau, P_B, h_B, P_D, h_D_min, h_D_max, alpha)));
            V2 = @(rB0, rD0, thetaD0) b(rD0, thetaD0) ./ (b(rD0, thetaD0) + a(rB0) * tau) .* exp(-tau ./ b(rD0, thetaD0) * N0 - 2 * pi * lambda_B * I1_V2(rB0, rD0, thetaD0, tau, P_B, h_B, P_D, alpha) - 2 * pi * lambda_D * (I2_V2(rD0, thetaD0, tau, P_D, h_D_min, h_D_max, alpha) + I3_V2(rD0, thetaD0, tau, P_D, h_D_min, h_D_max, alpha)));
            V3 = @(rB0, rD0, thetaD0) -a(rB0) .* b(rD0, thetaD0) .* (1 - tau ^ 2) ./ ((a(rB0) + b(rD0, thetaD0) * tau) .* (b(rD0, thetaD0) + a(rB0) * tau)) .* exp(-(1 ./ a(rB0) + 1 ./ b(rD0, thetaD0)) * tau / (1 - tau) * N0 - 2 * pi * lambda_B * I1_V3(rB0, rD0, thetaD0, tau, P_B, h_B, P_D, alpha) - 2 * pi * lambda_D * (I2_V3(rB0, rD0, thetaD0, tau, P_B, h_B, P_D, h_D_min, h_D_max, alpha) + I3_V3(rB0, rD0, thetaD0, tau, P_B, h_B, P_D, h_D_min, h_D_max, alpha)));
            
            if (thetaD0 <= theta_D_m) && (thetaD0 >= theta_D_M)
                W = V1(rB0, rD0, thetaD0) + (1 - V0(rB0, rD0, thetaD0, phiB0D0)) * (V2(rB0, rD0, thetaD0) + V3(rB0, rD0, thetaD0) * (tau < 1));
                fun = fun + W * f_z(z) * f_rB0(rB0) * f_rD0_thetaD0(rD0, thetaD0) * f_phiB0D0;
            end
        end
        toc
        ProbCover_Thr(i_tau, i_Height) = phiB0D0_max * rD0_max * thetaD0_max * rB0_max * z_max * fun / MaxIter;
    end
end
figure(516)
hold on
grid on
box on
plot(h_D_mean_vec, ProbCover_Thr.', 'LineWidth', 2, 'LineStyle', '-')
xlabel('Mean UAV Height $(h_{\rm D, m} + h_{\rm D, M}) / 2$ (m)', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('Coverage Probability', 'Interpreter', 'latex', 'FontSize', 12)
save('Comp_Height1_ProbCover_Thr', 'ProbCover_Thr')
datetime('now')

%% Required Functions
function I = I1_V1(rB0, tau, P_B, h_B, alpha)
a = @(rB0) P_B * G_B_OmniD(pi - acos(h_B ./ rB0)) .* rB0 .^ (-alpha);
I = integral(@(uBx) (1 - (1 + tau ./ a(rB0) .* P_B .* G_B_OmniD(pi - atan(uBx ./ h_B)) ./ (uBx .^ 2 + h_B ^ 2) .^ (alpha / 2)) .^ (-1)) .* uBx, sqrt(rB0 .^ 2 - h_B ^ 2), 1e4);% 1e4 is inf
end
function I = I1_V2(rB0, rD0, thetaD0, tau, P_B, h_B, P_D, alpha)
b = @(rD0, thetaD0) P_D * G_D_AC(pi - thetaD0) .* rD0 .^ (-alpha);
I = integral(@(uBx) (1 - (1 + tau ./ b(rD0, thetaD0) .* P_B .* G_B_OmniD(pi - atan(uBx ./ h_B)) ./ (uBx .^ 2 + h_B ^ 2) .^ (alpha / 2)) .^ (-1)) .* uBx, sqrt(rB0 .^ 2 - h_B ^ 2), 1e4);% 1e4 is inf
end
function I = I1_V3(rB0, rD0, thetaD0, tau, P_B, h_B, P_D, alpha)
a = @(rB0) P_B * G_B_OmniD(pi - acos(h_B ./ rB0)) .* rB0 .^ (-alpha);
b = @(rD0, thetaD0) P_D * G_D_AC(pi - thetaD0) .* rD0 .^ (-alpha);
I = integral(@(uBx) (1 - (1 + (1 ./ a(rB0) + 1 ./ b(rD0, thetaD0)) .* tau ./ (1 - tau) .* P_B .* G_B_OmniD(pi - atan(uBx ./ h_B)) ./ (uBx .^ 2 + h_B ^ 2) .^ (alpha / 2)) .^ (-1)) .* uBx, sqrt(rB0 .^ 2 - h_B ^ 2), 1e4);% 1e4 is inf
end

function I = I2_V1(rB0, rD0, tau, P_B, h_B, P_D, h_D_min, h_D_max, alpha)
a = @(rB0) P_B * G_B_OmniD(pi - acos(h_B ./ rB0)) .* rB0 .^ (-alpha);
theta_D_M_fun = @(r) acos(min(1, h_D_max ./ r));
theta_D_m_fun = @(r) acos(h_D_min ./ r);
I = integral2(@(thetaDx, rDx) (1 - (1 + tau ./ a(rB0) .* P_D .* G_D_AC(pi - thetaDx) .* rDx .^ (-alpha)) .^ (-1)) .* rDx .^ 2 .* sin(thetaDx), theta_D_M_fun(rD0), theta_D_m_fun(rD0), rD0, @(thetaDx) h_D_max ./ cos(thetaDx));
end
function I = I2_V2(rD0, thetaD0, tau, P_D, h_D_min, h_D_max, alpha)
b = @(rD0, thetaD0) P_D * G_D_AC(pi - thetaD0) .* rD0 .^ (-alpha);
theta_D_M_fun = @(r) acos(min(1, h_D_max ./ r));
theta_D_m_fun = @(r) acos(h_D_min ./ r);
I = integral2(@(thetaDx, rDx) (1 - (1 + tau ./ b(rD0, thetaD0) .* P_D .* G_D_AC(pi - thetaDx) .* rDx .^ (-alpha)) .^ (-1)) .* rDx .^ 2 .* sin(thetaDx), theta_D_M_fun(rD0), theta_D_m_fun(rD0), rD0, @(thetaDx) h_D_max ./ cos(thetaDx));
end
function I = I2_V3(rB0, rD0, thetaD0, tau, P_B, h_B, P_D, h_D_min, h_D_max, alpha)
a = @(rB0) P_B * G_B_OmniD(pi - acos(h_B ./ rB0)) .* rB0 .^ (-alpha);
b = @(rD0, thetaD0) P_D * G_D_AC(pi - thetaD0) .* rD0 .^ (-alpha);
theta_D_M_fun = @(r) acos(min(1, h_D_max ./ r));
theta_D_m_fun = @(r) acos(h_D_min ./ r);
I = integral2(@(thetaDx, rDx) (1 - (1 + (1 ./ a(rB0) + 1 ./ b(rD0, thetaD0)) .* tau ./ (1 - tau) .* P_D .* G_D_AC(pi - thetaDx) .* rDx .^ (-alpha)) .^ (-1)) .* rDx .^ 2 .* sin(thetaDx), theta_D_M_fun(rD0), theta_D_m_fun(rD0), rD0, @(thetaDx) h_D_max ./ cos(thetaDx));
end

function I = I3_V1(rB0, rD0, tau, P_B, h_B, P_D, h_D_min, h_D_max, alpha)
a = @(rB0) P_B * G_B_OmniD(pi - acos(h_B ./ rB0)) .* rB0 .^ (-alpha);
theta_D_m_fun = @(r) acos(h_D_min ./ r);
I = integral2(@(thetaDx, rDx) (1 - (1 + tau ./ a(rB0) .* P_D .* G_D_AC(pi - thetaDx) .* rDx .^ (-alpha)) .^ (-1)) .* rDx .^ 2 .* sin(thetaDx), theta_D_m_fun(rD0), pi / 2 - 0.05, @(thetaDx) h_D_min ./ cos(thetaDx), @(thetaDx) h_D_max ./ cos(thetaDx));% pi / 2 - 0.05 is pi / 2
end
function I = I3_V2(rD0, thetaD0, tau, P_D, h_D_min, h_D_max, alpha)
b = @(rD0, thetaD0) P_D * G_D_AC(pi - thetaD0) .* rD0 .^ (-alpha);
theta_D_m_fun = @(r) acos(h_D_min ./ r);
I = integral2(@(thetaDx, rDx) (1 - (1 + tau ./ b(rD0, thetaD0) .* P_D .* G_D_AC(pi - thetaDx) .* rDx .^ (-alpha)) .^ (-1)) .* rDx .^ 2 .* sin(thetaDx), theta_D_m_fun(rD0), pi / 2 - 0.05, @(thetaDx) h_D_min ./ cos(thetaDx), @(thetaDx) h_D_max ./ cos(thetaDx));% pi / 2 - 0.05 is pi / 2
end
function I = I3_V3(rB0, rD0, thetaD0, tau, P_B, h_B, P_D, h_D_min, h_D_max, alpha)
a = @(rB0) P_B * G_B_OmniD(pi - acos(h_B ./ rB0)) .* rB0 .^ (-alpha);
b = @(rD0, thetaD0) P_D * G_D_AC(pi - thetaD0) .* rD0 .^ (-alpha);
theta_D_m_fun = @(r) acos(h_D_min ./ r);
I = integral2(@(thetaDx, rDx) (1 - (1 + (1 ./ a(rB0) + 1 ./ b(rD0, thetaD0)) .* tau ./ (1 - tau) .* P_D .* G_D_AC(pi - thetaDx) .* rDx .^ (-alpha)) .^ (-1)) .* rDx .^ 2 .* sin(thetaDx), theta_D_m_fun(rD0), pi / 2 - 0.05, @(thetaDx) h_D_min ./ cos(thetaDx), @(thetaDx) h_D_max ./ cos(thetaDx));% pi / 2 - 0.05 is pi / 2
end