function G = G_D_AC(theta)
SLA = 30;
theta_3dB_D_AC = deg2rad(120);
G_max = 8;
G_dB = G_max - min(12 * ((theta - pi) / theta_3dB_D_AC) .^ 2, SLA);
G = db2pow(G_dB);
end