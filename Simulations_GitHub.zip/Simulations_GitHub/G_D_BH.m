function G = G_D_BH(theta, phi, theta0, phi0)
SLA = 30;
theta_3dB_D_BH = deg2rad(10);
phi_3dB_D_BH = deg2rad(10);
G_max = 8;
G_V = min(12 * ((theta - theta0) / theta_3dB_D_BH) .^ 2, SLA);
G_H = min(12 * ((phi - phi0) / phi_3dB_D_BH) .^ 2, SLA);
G_dB = G_max - min(G_V + G_H, SLA);
G = db2pow(G_dB);
end