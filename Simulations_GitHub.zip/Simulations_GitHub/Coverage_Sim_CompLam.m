%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: Fundamentals of 3D Two-Hop Cellular Networks Analysis      %%%
%%%          with Wireless Backhauled UAVs                              %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the simulation data for Fig. 5,     %%%
%%%   coverage probability as a function of UAV density.                %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Parameters
datetime('now')
lambda_B = 1e-6;
R_B = 1e5;
h_B = 20;
Num_B_Initial = lambda_B * pi * R_B ^ 2;
lambda_D_vec = [(1 : 10) * 1e-9, (2 : 5) * 1e-8];
Num_Lam = length(lambda_D_vec);
R_D = 1e5;
h_D_min = 50;
h_D_max = 200;
Num_D_Initial_vec = lambda_D_vec * pi * R_D ^ 2 * (h_D_max - h_D_min);
alpha = 3;
m = 1;
N0 = 1e-8;
P_B = db2pow(10);
P_D = db2pow(5);
G_U = db2pow(0);
tauVec_dB = (-12 : 4 : 0).';
tauVec = db2pow(tauVec_dB);
tauLen = length(tauVec);
ProbCover_Sim = zeros(tauLen, Num_Lam);
Realizations = 1e4;%5;
%% Simulation
for i_Lam = 1 : Num_Lam
    Num_D_Initial = Num_D_Initial_vec(i_Lam);
    SINR = zeros(Realizations, 1);
    tic
    parfor i = 1 : Realizations
        Num_B = poissrnd(Num_B_Initial);
        Pos_B = zeros(Num_B, 3);
        Pos_B_range2D = unifrnd(0, 1, Num_B, 1);
        Pos_B_range2D = R_B * sqrt(Pos_B_range2D);
        Pos_B_phi = unifrnd(0, 2 * pi, Num_B, 1);
        Pos_B(:, 1 : 2) = repmat(Pos_B_range2D, 1, 2) .* [cos(Pos_B_phi), sin(Pos_B_phi)];
        Pos_B(:, 3) = h_B;
        Pos_B_range = sqrt(sum(Pos_B .^ 2, 2)); % BS to UE distances
        Pos_B_theta = acos(h_B ./ Pos_B_range);
        [r_tilde_B, ind_min_B] = min(Pos_B_range);
        theta_tilde_B = Pos_B_theta(ind_min_B);
        phi_tilde_B = Pos_B_phi(ind_min_B);
        Pos_B0_Sphr = [r_tilde_B, theta_tilde_B, phi_tilde_B];
        Pos_B0_Cart = Pos_B(ind_min_B, :);
        
        Num_D = poissrnd(Num_D_Initial);
        Pos_D = zeros(Num_D, 3);
        Pos_D_z = unifrnd(h_D_min, h_D_max, [Num_D, 1]);
        Pos_D_range2D = unifrnd(0, 1, Num_D, 1);
        Pos_D_range2D = R_D * sqrt(Pos_D_range2D);
        Pos_D_phi = unifrnd(0, 2 * pi, Num_D, 1);
        Pos_D(:, 1 : 2) = repmat(Pos_D_range2D, 1, 2) .* [cos(Pos_D_phi), sin(Pos_D_phi)];
        Pos_D(:, 3) = Pos_D_z;
        Pos_D_range = sqrt(sum(Pos_D .^ 2, 2)); % UAV to UE distances
        Pos_D_theta = acos(Pos_D_z ./ Pos_D_range);
        [r_tilde_D, ind_min_D] = min(Pos_D_range);
        theta_tilde_D = Pos_D_theta(ind_min_D);
        phi_tilde_D = Pos_D_phi(ind_min_D);
        Pos_D0_Sphr = [r_tilde_D, theta_tilde_D, phi_tilde_D];
        Pos_D0_Cart = Pos_D(ind_min_D, :);
        
        r_B0D0 = sqrt(sum((Pos_D0_Cart - Pos_B0_Cart) .^ 2, 2));
        r_BxD0 = sqrt(sum((Pos_D0_Cart - Pos_B) .^ 2, 2)); % 'x' means 'all', not just interferers
        r_DxD0 = sqrt(sum((Pos_D0_Cart - Pos_D) .^ 2, 2));
        r_DxD0(r_DxD0 == 0) = inf;
        r_B0U = Pos_B0_Sphr(1);
        r_BxU = Pos_B_range;
        r_D0U = Pos_D0_Sphr(1);
        r_DxU = Pos_D_range;
        theta_B0D0 = acos((Pos_D0_Cart(3) - h_B) / r_B0D0); % Measured with respect to the z-axis
        theta_BxD0 = acos((Pos_D0_Cart(3) - h_B) ./ r_BxD0);
        theta_DxD0 = acos((Pos_D0_Cart(3) - Pos_D_z) ./ r_DxD0);
        theta_B0U = pi - Pos_B0_Sphr(2);
        theta_BxU = pi - Pos_B_theta;
        theta_D0U = pi - Pos_D0_Sphr(2);
        theta_DxU = pi - Pos_D_theta;
        phi_B0D0 = Pos_D0_Sphr(3) - Pos_B0_Sphr(3); % Measured in the xy-plane with respect to the x-axis
        phi_BxD0 = Pos_D0_Sphr(3) - Pos_B_phi;
        phi_DxD0 = Pos_D0_Sphr(3) - Pos_D_phi;
        
        Fading_B2U = gamrnd(m, 1 / m, Num_B, 1);
        Fading_D2U = gamrnd(m, 1 / m, Num_D, 1);
        Fading_D2U0 = Fading_D2U(ind_min_D);
        Fading_B2D = gamrnd(m, 1 / m, Num_B, 1);
        Fading_D2D = gamrnd(m, 1 / m, Num_D, 1);
        
        P_B0_Rx = P_B * G_U  * G_B_OmniD(theta_B0U) * Fading_B2U(ind_min_B) * r_B0U ^ (-alpha);
        P_D0_Rx = P_D * G_U * G_D_AC(theta_D0U) * Fading_D2U0 * r_D0U ^ (-alpha);
        P_B0D0_Rx = P_B * G_D_BH(pi - theta_B0D0, -phi_B0D0, pi - theta_B0D0, -phi_B0D0) * G_B_OmniD(theta_B0D0) * Fading_B2D(ind_min_B) * r_B0D0 ^ (-alpha);
        
        I_BU = sum(P_B * G_U * G_B_OmniD(theta_BxU) .* Fading_B2U .* r_BxU .^ (-alpha)) - P_B0_Rx;
        I_DU = sum(P_D * G_U * G_D_AC(theta_DxU) .* Fading_D2U .* r_DxU .^ (-alpha)) - P_D0_Rx;
        I_U = I_BU + I_DU;
        
        SINR_BU = P_B0_Rx / (I_U + P_D0_Rx + N0);
        SINR_DU = P_D0_Rx / (I_U + P_B0_Rx + N0);
        SINR_BD = P_B0D0_Rx / N0;
        SINR_e2e = min(SINR_BD, SINR_DU);
        SINR(i) = max(SINR_BU, SINR_e2e);
    end
    toc
    for i_tau = 1 : tauLen
        ProbCover_Sim(i_tau, i_Lam) = nnz(SINR >= tauVec(i_tau)) / Realizations;
    end
end
figure(418)
grid on
box on
semilogx(lambda_D_vec, ProbCover_Sim.', 'LineWidth', 2, 'LineStyle', '-')%, 'Marker', 'o', 'MarkerFaceColor', 'w', 'MarkerEdgeColor', 'k', 'MarkerSize', 5)
hold on
decimate_ind = [1, 4, 7, 10, 11, 12, 13, 14];
semilogx(lambda_D_vec(decimate_ind), ProbCover_Sim(:, decimate_ind).', 'LineWidth', 2, 'LineStyle', 'none', 'Marker', 'o', 'MarkerFaceColor', 'w', 'MarkerEdgeColor', 'k', 'MarkerSize', 5)
xlabel('UAV Density $\lambda_{\rm D}$', 'Interpreter', 'latex', 'FontSize', 12)
ylabel('Coverage Probability', 'Interpreter', 'latex', 'FontSize', 12)
save('Comp_Lam_ProbCover_Sim', 'ProbCover_Sim')
datetime('now')